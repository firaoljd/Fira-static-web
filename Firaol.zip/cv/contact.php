<?php
$conn =new mysqli("localhost","root","root","fira");
// connecting php with html
if($conn->connect_error){
    die("connection faild:" .$conn->connect_error);
}
$name=$_POST['name'];
$email=$_POST['email'];
$phone no.=$_POST['phone no.'];
$message=$_POST['message'];


$stm = $conn->prepare("INSERT INTO fira(name,email,phone no.,message)");
$stm->bind_param("sss",$name,$email,$phone no.,$message,);
if($stm->execute()){
    echo"Message stored!";
}
else{
    echo"Error!". $stmt->error;
}
$stm->close();
$conn->close();
?>